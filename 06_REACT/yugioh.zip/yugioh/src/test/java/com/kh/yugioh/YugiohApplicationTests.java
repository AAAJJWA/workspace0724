package com.kh.yugioh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YugiohApplicationTests {

	@Test
	void contextLoads() {
	}

}
